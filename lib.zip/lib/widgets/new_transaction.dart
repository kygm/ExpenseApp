import 'package:flutter/material.dart';

class NewTransaction extends StatefulWidget {
  final Function addTx;

  NewTransaction(this.addTx);

  @override
  _NewTransactionState createState() => _NewTransactionState();
}

class _NewTransactionState extends State<NewTransaction> {
  final titleController = TextEditingController();

  final amountController = TextEditingController();

  void submitData() {
    final enteredExpenseItem = titleController.text;
    
    final enteredAmount = double.parse(amountController.text);
    if (enteredExpenseItem.isEmpty || enteredAmount <= 0) {
      return;
    }
    widget.addTx(
      titleController.text,
      double.parse(amountController.text),
    );
    //makes text/digit input dialog
    //automatically go away when action
    //happens
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Container(
        padding: EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            TextField(
              controller: titleController,
              onSubmitted: (_) =>
                  submitData(), //underscore (_) is a dummy value that is never used
              decoration: InputDecoration(
                labelText: 'Expense Item',
              ),
            ),
            TextField(
              controller: amountController,
              onSubmitted: (_) => submitData(),
              decoration: InputDecoration(
                labelText: 'Amount',
              ),
              keyboardType: TextInputType.number,
            ),
            FlatButton(
              onPressed: submitData,
              child: Text('Add Item'),
              textColor: Colors.purple,
            ),
          ],
        ),
      ),
    );
  }
}
